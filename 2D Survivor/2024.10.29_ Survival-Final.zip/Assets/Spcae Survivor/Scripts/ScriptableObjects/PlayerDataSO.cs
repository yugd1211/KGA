using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.GlobalIllumination;

[CreateAssetMenu(fileName = "PlayerData", menuName = "ScriptableObjects/PlayerDataSO", order = 0)]
public class PlayerDataSO : ScriptableObject
{
	// asset ���Ϸ� ���� �� �����͸� �Է��� �� �ִ�.
	public string characterName;
	public float hp;
	public float damage;
	public float moveSpeed;
	public Sprite sprite;
	public GameObject startSkillPrefab;
	public bool rotateRenderer;
}
