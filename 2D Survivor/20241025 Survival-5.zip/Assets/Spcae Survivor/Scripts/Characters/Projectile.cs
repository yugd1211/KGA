using System.Collections;
using System.Collections.Generic;
using UnityEditor.ShaderKeywordFilter;
using UnityEngine;
using Lean.Pool;

public class Projectile : MonoBehaviour
{
	public float damage;
	public float moveSpeed;
	public float duration;
	public ParticleSystem impactParticle;

	public int pierceCount = 0;


	private CircleCollider2D coll;

	private void Awake()
	{
		coll = GetComponent<CircleCollider2D>();
		// coll.enabled = false;
	}

	private void OnEnable() // start���� ���� �����
	{
		//LeanPool.Despawn(this, duration); // 3�� �ڿ� Ǯ�� ���ư�
		StartCoroutine(PushDelay(duration));
	}


	List<Collider2D> contactedColls = new List<Collider2D>();
	// OverlapCircle �Լ��� ���� ������ ���� �ִ� �ݶ��̴��� ���� List

	private void Update()
	{
		Move(Vector2.up);
	}

	public void Move(Vector2 dir)
	{
		transform.Translate(dir * moveSpeed * Time.deltaTime);
	}


	private void OnTriggerEnter2D(Collider2D other)
	{
		if (other.transform.CompareTag("Enemy"))
		{
			// other.gameObject.GetComponent<Enemy>().TakeDamage(damage);
			// ParticleSystem p = Instantiate(impactParticle, transform.position, Quaternion.identity);
			// p.Play();
			pierceCount--;
			ParticleSystem p = Instantiate(impactParticle, transform.position, Quaternion.identity);
			other.GetComponent<Enemy>()?.TakeDamage(damage);
			p.Play();
			Destroy(p, 2f);
			if (pierceCount == 0)
			{
				PoolManager.Instance.Remove(this);
				// PoolManager.Instance.projectilePool.Push(this);
			}
		}
	}
	private IEnumerator PushDelay(float delay)
	{
		yield return new WaitForSeconds(delay);
		// PoolManager.Instance.projectilePool.Push(this);
		PoolManager.Instance.Remove(this);
	}

	private void OnDisable()
	{
		contactedColls.Clear();
	}
}
